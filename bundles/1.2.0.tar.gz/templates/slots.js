/* insta-autopilot 템플릿 데이터 주입 (렌더 전용, 외부 의존 없음)
 *
 * await window.renderSlots({
 *   variant: 'A' | 'B' | 'C',                 // 템플릿 종류
 *   brand:   {accent, bg, cta, text, font},   // --brand-* 로 들어감 (선택)
 *   slots:   {l1, l2, l3, chip, date, handle, credit, photo, logo, character,
 *             'cta.pitch', 'cta.pitch_em', 'cta.name', 'cta.handle', 'cta.card_desc',
 *             'cta.button', 'cta.button_done', 'cta.after', 'cta.background'}
 * })
 *   - 텍스트 슬롯은 textContent 로만 넣는다(HTML 해석 안 함). 줄바꿈은 \n.
 *   - 이미지 슬롯(photo, logo, character, cta.background)은 URL(file:, data:, https:).
 *   - 비어 있는 슬롯은 요소에 data-empty 를 붙여 숨긴다.
 *   - 모든 이미지·폰트 로드가 끝나면 resolve 하고 body[data-ready="1"] 이 된다.
 * window.ctaSeek(seconds)  : CTA 애니메이션을 해당 시점(0~3초)에 멈춘다 (프레임 캡처용)
 * window.ctaPlay()         : CTA 애니메이션을 처음부터 실시간 재생
 */
(function () {
  const IMAGE_SLOTS = { photo: 'bg', 'cta.background': 'bg', logo: 'img', 'cta.logo': 'img', character: 'img' };
  const VARS = { accent: '--brand-accent', bg: '--brand-bg', cta: '--brand-cta', text: '--brand-text', font: '--brand-font' };

  function loadImage(url) {
    return new Promise((resolve) => {
      const im = new Image();
      im.onload = () => resolve(true);
      im.onerror = () => resolve(false);
      im.src = url;
    });
  }

  function setText(el, value, em) {
    el.textContent = '';
    if (!em || value.indexOf(em) < 0) { el.textContent = value; return; }
    const i = value.indexOf(em);
    el.append(document.createTextNode(value.slice(0, i)));
    const e = document.createElement('em');
    e.textContent = em;
    el.append(e, document.createTextNode(value.slice(i + em.length)));
  }

  window.renderSlots = async function (data) {
    data = data || {};
    const slots = data.slots || {};
    const root = document.documentElement;
    Object.entries(data.brand || {}).forEach(([k, v]) => { if (VARS[k] && v) root.style.setProperty(VARS[k], v); });

    document.querySelectorAll('.canvas').forEach((c) => {
      c.classList.remove('vA', 'vB', 'vC');
      c.classList.add('v' + (data.variant || 'A'));
    });

    const waits = [];
    document.querySelectorAll('[data-slot]').forEach((el) => {
      const key = el.dataset.slot;
      const raw = slots[key];
      const value = raw == null ? '' : String(raw);
      el.removeAttribute('data-empty');
      const kind = IMAGE_SLOTS[key];
      if (kind === 'bg') {
        if (value) { el.style.backgroundImage = 'url("' + value.replace(/"/g, '%22') + '")'; waits.push(loadImage(value)); }
        else el.style.backgroundImage = '';
        return;
      }
      if (kind === 'img') {
        // 이미지가 없으면 대체 텍스트(data-fallback 슬롯 값)를 보여 준다
        el.textContent = '';
        if (value) {
          const im = document.createElement('img');
          im.alt = '';
          im.src = value;
          el.append(im);
          waits.push(loadImage(value));
        } else if (el.dataset.fallback && slots[el.dataset.fallback]) {
          el.textContent = String(slots[el.dataset.fallback]).slice(0, 4);
        }
        return;
      }
      if (!value) { el.textContent = ''; el.setAttribute('data-empty', ''); return; }
      setText(el, value, key === 'cta.pitch' ? slots['cta.pitch_em'] : null);
    });

    // 핸들 줄은 handle 슬롯이 비면 통째로 숨김
    document.querySelectorAll('.handle').forEach((h) => {
      const t = h.querySelector('[data-slot="handle"]');
      if (t && t.hasAttribute('data-empty')) h.setAttribute('data-empty', ''); else h.removeAttribute('data-empty');
    });

    await Promise.all(waits);
    if (document.fonts && document.fonts.ready) await document.fonts.ready;
    document.body.dataset.ready = '1';
    return true;
  };

  function ctaCanvas() { return document.querySelector('.canvas'); }

  window.ctaPlay = function () {
    const c = ctaCanvas();
    c.classList.remove('play'); void c.offsetWidth; c.classList.add('play');
  };

  window.ctaSeek = function (seconds) {
    const c = ctaCanvas();
    if (!c.classList.contains('play')) c.classList.add('play');
    document.getAnimations().forEach((a) => { a.pause(); a.currentTime = Math.max(0, seconds) * 1000; });
  };
})();
